import { Component } from '@angular/core';

@Component({
  selector: 'app-admin2',
  templateUrl: './admin2.component.html',
  styleUrls: ['./admin2.component.css'],
  host: {['class']: 'tw-grow tw-flex tw-flex-col'}
})
export class Admin2Component {

}
