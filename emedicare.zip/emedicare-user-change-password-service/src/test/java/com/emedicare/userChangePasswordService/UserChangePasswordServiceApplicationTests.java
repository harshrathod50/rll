package com.emedicare.userChangePasswordService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserChangePasswordServiceApplicationTests {

  @Test
  void contextLoads() {}
}
