package com.emedicare.userRegisterService;

import com.emedicare.userRegisterService.configuration.ApplicationConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApplicationConfiguration.class)
class UserRegisterServiceApplicationTests {

  @Test
  void contextLoads() {}
}
