package com.paycart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PurchaseCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
