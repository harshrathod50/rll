package com.emedicare.paymentService;

import com.rathod.harsh.store.configuration.ApplicationConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApplicationConfiguration.class)
class PaymentServiceApplicationTests {

  @Test
  void contextLoads() {}
}
