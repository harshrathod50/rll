SELECT 'Initializes MySQL database with data provided below';

INSERT IGNORE INTO emedicare_payment_credit_card (`credit_card_id`, `card_number`, `card_holder_name`, `expiry_month`, `expiry_year`, `cvv`) VALUES (1, '4858495955595290', 'Drayton Constantino', 4, 2028, 277);
INSERT IGNORE INTO emedicare_payment_credit_card (`credit_card_id`, `card_number`, `card_holder_name`, `expiry_month`, `expiry_year`, `cvv`) VALUES (2, '4383360769164317', 'Laykin Moline', 6, 2027, 924);
INSERT IGNORE INTO emedicare_payment_credit_card (`credit_card_id`, `card_number`, `card_holder_name`, `expiry_month`, `expiry_year`, `cvv`) VALUES (3, '4729389673105051', 'Heather Spaulding', 3, 2026, 737);
INSERT IGNORE INTO emedicare_payment_credit_card (`credit_card_id`, `card_number`, `card_holder_name`, `expiry_month`, `expiry_year`, `cvv`) VALUES (4, '4071627823428111', 'Emberlynn Mcduffie', 7, 2026, 247);
INSERT IGNORE INTO emedicare_payment_credit_card (`credit_card_id`, `card_number`, `card_holder_name`, `expiry_month`, `expiry_year`, `cvv`) VALUES (5, '4939848873449003', 'Parris Haldeman', 12, 2026, 865);
INSERT IGNORE INTO emedicare_payment_credit_card (`credit_card_id`, `card_number`, `card_holder_name`, `expiry_month`, `expiry_year`, `cvv`) VALUES (6, '4857306041507838', 'Maesyn Redfern', 10, 2024, 974);
INSERT IGNORE INTO emedicare_payment_credit_card (`credit_card_id`, `card_number`, `card_holder_name`, `expiry_month`, `expiry_year`, `cvv`) VALUES (7, '4998715417331849', 'Kelley Campana', 5, 2028, 757);
INSERT IGNORE INTO emedicare_payment_credit_card (`credit_card_id`, `card_number`, `card_holder_name`, `expiry_month`, `expiry_year`, `cvv`) VALUES (8, '4541249077612928', 'Shilah Peachey', 7, 2028, 789);
