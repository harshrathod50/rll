package com.emedicare.userPaymentService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserPaymentServiceApplicationTests {

  @Test
  void contextLoads() {}
}
