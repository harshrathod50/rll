package com.emedicare;

import com.emedicare.userAddressService.configuration.ApplicationConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApplicationConfiguration.class)
class UserAddressServiceApplicationTests {

  @Test
  void contextLoads() {}
}
