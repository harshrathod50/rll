package com.emedicare.productService;

import com.emedicare.productService.configuration.ApplicationConfiguration;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ApplicationConfiguration.class)
class ProductServiceApplicationTests {

  @Test
  void contextLoads() {}
}
