package com.company.rll;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RllApplicationTests {

  @Test
  void contextLoads() {}
}
