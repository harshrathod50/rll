import { Component } from '@angular/core';

@Component({
  selector: 'app-user2',
  templateUrl: './user2.component.html',
  styleUrls: ['./user2.component.css'],
  host: {['class']: 'tw-grow tw-flex tw-flex-col'}
})
export class User2Component {

}
