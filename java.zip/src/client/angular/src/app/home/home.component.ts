import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  host: {['class']: 'tw-grow tw-flex tw-flex-col'}
})
export class HomeComponent {

}
