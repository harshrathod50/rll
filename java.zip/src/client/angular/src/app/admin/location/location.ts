export default interface Location {
  locationId: Number;
  terminal: String;
  city: String;
  province: String;
}
