# rll

## IDE

* Visual Studio Code
  * Download and install [JetBrains Mono](https://fonts.google.com/specimen/JetBrains+Mono?query=JetBrains) to apply font ligatures.
